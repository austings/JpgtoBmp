﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jpgtobmp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {

                // Open a Stream and decode a JPEG image
                String driectory = textBox1.Text;
                String directoryOut = textBox2.Text;
                string[] files = null;
                    files = System.IO.Directory.GetFiles(driectory);
                    foreach (string file in files)
                    {
                        Image image = System.Drawing.Image.FromFile(file);
                       string newname = Path.ChangeExtension(Path.GetFileName(file), ".bmp");
                        image.Save(directoryOut + "/" + (newname), System.Drawing.Imaging.ImageFormat.Bmp);
                    }
              

            }
            catch (Exception err)
            {
                Console.WriteLine("File Not Found! Full Stack Trace: " + err);
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
